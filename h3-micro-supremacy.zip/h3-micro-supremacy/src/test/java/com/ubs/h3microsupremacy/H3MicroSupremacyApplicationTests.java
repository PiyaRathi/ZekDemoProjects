package com.ubs.h3microsupremacy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H3MicroSupremacyApplicationTests {

	@Test
	void contextLoads() {
	}

}
